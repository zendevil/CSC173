Collaborators
Prikshet Sharma. NetId: pshar10

Nathan McCloud. NetId: nmccloud

Henry Hogthorne. 


We used gcc compiler in codeblocks. We think that you can also compile it using your
 terminal/command prompt. The command for that should be:




gcc auto.c -o auto

To run it: 

./auto


Thank you!