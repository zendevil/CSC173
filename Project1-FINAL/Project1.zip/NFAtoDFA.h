#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "nfa.h"
#include "IntSet.h"

extern DFA *NFAtoDFA(NFA *nfa);

extern DFAState *DFAStatenew();
